import time
import win32api, win32con
from pynput.mouse import Button, Controller
import os
import random

# Made by HtmlHorse.com
mouse = Controller()

xpos = -1
ypos = -1
mbutton = "left"
delay = 4

def runscript():
	while True:
		if delay >0:
			time.sleep(delay)
		else:
			randomdelay = random.randint(1,15)
			time.sleep(randomdelay)

		if xpos >0 and ypos >0:
			mouse.position = (xpos,ypos)

		if mbutton == 'left':
			mouse.press(Button.left)
			time.sleep(0.06)
			mouse.release(Button.left)
		elif mbutton == 'right':
			mouse.press(Button.right)
			time.sleep(0.06)
			mouse.release(Button.right)
		else:
			mouse.press(Button.left)
			time.sleep(0.06)
			mouse.release(Button.left)

def run_locate():
	global xpos, ypos
	print("Locate the position of click")
	locate_input = input("\n\'cord\', \'snap\' or \'none\'\nEnter Input: ").strip().lower()
	
	if locate_input == 'cord':
		xpos = int(input("\nEnter X pos: ").strip().lower())
		ypos = int(input("\nEnter Y pos: ").strip().lower())
	elif locate_input == 'snap':
		print("After 3 seconds, your mouse position will be recorded...")
		time.sleep(3)
		xpos = mouse.position[0]
		ypos = mouse.position[1]
		print(f"Click position locked at X:{xpos} Y:{ypos}")
	elif locate_input == 'none':
		xpos = -1
		ypos = -1


def run_mbutton():
	global mbutton
	button_input = input("\n\'right\', \'R\', \'left\', \'L\'\nEnter Input: ").strip().lower()
	if button_input == 'left' or button_input == 'l':
		mbutton = "left"
	elif button_input == 'right' or button_input == 'r':
		mbutton = "right"
	else:
		print("Unknown button, nothing changed!")

def run_interval():
	global delay
	delay_input = float(input("\nnEnter delay duration in seconds: ").strip().lower())
	delay = delay_input


def print_help():
	print("\nWelcome to AutoClicker-Combo")
	print("\n1. Select mouse location using \'locate\' or \'L\'.") 
	print("		This will ask for a method; \'cord\', \'snap\' or \'none\'.")
	print("		With \'snap\' it will get the location of mouse after 3 seconds.")
	print("		With \'cord\' enter x then enter y.")
	print("		With \'none\' wherever mouse is for all the time (Not recommended for afk).")
	print("\n2. Select which mouse button will be clicked using \'mbutton\' or \'mb\'.")
	print("		This will ask for input; \'right\', \'R\', \'left\', \'L\'")
	print("\n3. Select click interval using \'interval\' or \'delay\'")
	print("		This will ask for time in seconds, only positive")
	print("		This allows fractions, such as \'0.3\'")
	print("	!!--Be careful, if you set position and small delay you may lock yourself!!")
	print("		Entering \'-1\' or negative will result in randomized delay from 1-15 seconds")
	print("\n4. Check current selections with \'info\' or \'i\'.")
	print("\n5. To stop the script, press \'ctrl+c\' on cmd screen")
	print("		(WIP) Stop program using a button via threading")
	print("\n6. If everything is set, \'runscript\' to start the auto clicking")
	print("\n7. To clean this screen \'clear\' or \'cls\'")
	print("\n\nThanks for using AutoClicker-combo")


def main():
	os.system("cls")
	while True:
		print("\nWelcome to AutoClicker-Combo by HtmlHorse")
		user_input = input("\nHelp for more info!\nEnter Input: ").strip().lower()

		if user_input == 'locate' or user_input == 'l':
			run_locate()
		elif user_input == 'mbutton' or user_input == 'mb':
			run_mbutton()
		elif user_input == 'interval' or user_input == 'delay':
			run_interval()
		elif user_input == 'info' or user_input == 'i':
			print(f"X: {xpos} Y: {ypos}\nMouse: {mbutton}\nDelay: {delay}")
		elif user_input == 'runscript':
			runscript()
		elif user_input == 'help':
			print_help()
		elif user_input == 'cls' or user_input == 'clear':
			os.system("cls")
		else:
			print("Unknown command")
			print_help()

if __name__ == "__main__":
	main()

# Made by HtmlHorse.com